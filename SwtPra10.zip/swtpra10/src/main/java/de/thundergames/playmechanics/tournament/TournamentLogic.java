package de.thundergames.playmechanics.tournament;

public class TournamentLogic {
}
