# swtpra10

## Gitlab main branch

Carina Schoppe: Produktmanagerin, Developerin

Lennart Kunkel: Produktmanager

Marc W: Scrum Master

Eva Juo: Testmanagerin

Jana R: Testmanagerin

Issam Mani: Entwickler, Qualitätsmanager

Nick Lührmann: Scrum Master

Nicole Malgorzata M: Dokumentationsmanagerin

Philipp F: Werkzeugbeauftragter

Dila C: Entwicklerin

Alp B: Entwickler

Michael A: Product Owner, Komitee

