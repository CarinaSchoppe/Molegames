Copyright Notice for $project.name                                            
Copyright (c)$originalComment.match("Copyright \(c\) (\d+)", 1, "-") at ThunderGames | SwtPra10 $today.year                              
File created on $today by $username The Latest changes made by $username on $file.lastModified All contents of "$file.className" are protected by copyright. The copyright law, unless expressly indicated otherwise, is  
at ThunderGames | SwtPra10. All rights reserved                         
Any type of duplication, distribution, rental, sale, award,  
Public accessibility or other use                            
requires the express written consent of ThunderGames | SwtPra10.
